<?php
/**
 * Variables de entorno para producción (Hostinger)
 * Este archivo NO debe subirse a repositorios públicos
 * Cargado automáticamente por public/index.php
 */

// Ruta base de la aplicación
putenv('APP_BASE_PATH=/AppEgresados');

// Base de datos
putenv('APP_DB_HOST=localhost');
putenv('APP_DB_PORT=3306');
putenv('APP_DB_NAME=u372206659_bolsa_trabajo');
putenv('APP_DB_USER=u372206659_bolsa');
putenv('APP_DB_PASS=Bolsa@Trabajo2026!');

// SMTP para servidor (recomendado en producción)
// Si MAIL_DRIVER se mantiene en "log", el sistema NO enviará correos reales
// y guardará los códigos en storage/logs/emails.log
putenv('MAIL_DRIVER=smtp');
putenv('MAIL_HOST=smtp.gmail.com');
putenv('MAIL_PORT=587');
putenv('MAIL_ENCRYPTION=tls');
putenv('MAIL_USER=egresadosapp.ti@gmail.com');
putenv('MAIL_PASS=arxoiicxnnllyfyl');
putenv('MAIL_FROM=egresadosapp.ti@gmail.com');
putenv('MAIL_FROM_NAME=Bolsa de Trabajo UTP');
